package common;

public class Constantes {
    public static final String PUNTO_Y_COMA = ";";
    public static final String ID = "id";
    public static final String SQL_PROPERTIES_PATH = "src/main/resources/mysql-properties.xml";

    private Constantes() {
    }
}

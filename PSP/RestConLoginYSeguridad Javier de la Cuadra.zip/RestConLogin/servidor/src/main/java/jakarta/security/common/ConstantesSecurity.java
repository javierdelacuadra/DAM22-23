package jakarta.security.common;

public class ConstantesSecurity {
    public static final String ADMIN = "admin";
    public static final String USER = "user";
    public static final String CREDENTIAL = "CREDENTIAL";
    public static final String BASIC = "Basic";
    public static final String REGEX = " ";
}

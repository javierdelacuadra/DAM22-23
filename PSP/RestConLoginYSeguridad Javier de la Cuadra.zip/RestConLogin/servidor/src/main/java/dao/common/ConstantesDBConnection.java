package dao.common;

public class ConstantesDBConnection {
    public ConstantesDBConnection() {
    }

    public static final String URL_DB = "urlDB";
    public static final String USER_NAME = "user_name";
    public static final String PASSWORD = "password";
    public static final String DRIVER = "driver";
    public static final String CACHE_PREP_STMTS = "cachePrepStmts";
    public static final String PREP_STMT_CACHE_SIZE = "prepStmtCacheSize";
    public static final String PREP_STMT_CACHE_SQL_LIMIT = "prepStmtCacheSqlLimit";
}

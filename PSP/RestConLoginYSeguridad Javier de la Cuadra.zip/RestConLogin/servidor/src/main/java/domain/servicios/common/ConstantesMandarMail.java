package domain.servicios.common;

public class ConstantesMandarMail {
    public ConstantesMandarMail() {
    }

    public static final String MAIL_SMTP_PORT = "mail.smtp.port";
    public static final String PORT_NUMBER = "587";
    public static final String MAIL_SMTP_AUTH = "mail.smtp.auth";
    public static final String TRUE = "true";
    public static final String MAIL_SMTP_SSL_TRUST = "mail.smtp.ssl.trust";
    public static final String SMTP_GMAIL_COM = "smtp.gmail.com";
    public static final String MAIL_SMTP_STARTTLS_ENABLE = "mail.smtp.starttls.enable";
    public static final String TEXT_HTML = "text/html";
    public static final String SMTP = "smtp";
    public static final String ALUMNOSDAMQUEVEDO_GMAIL_COM = "alumnosdamquevedo@gmail.com";
    public static final String AYUAKLCKGXBBOOPH = "ayuaklckgxbbooph";
}

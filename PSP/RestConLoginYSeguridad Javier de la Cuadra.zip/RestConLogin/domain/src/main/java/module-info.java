module domain {
    requires lombok;
    exports model;
    opens model;
}
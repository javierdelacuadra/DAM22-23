package data.common;

public class ConstantesDao {
    public ConstantesDao() {
    }

    public static final String APPLICATION_JSON = "application/json";
}

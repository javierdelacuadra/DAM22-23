package ui.pantallas.pantallamain;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class PantallaMainState {
    public String mensaje;
}

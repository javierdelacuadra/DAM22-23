package ui.pantallas.pantallalogin;

import lombok.AllArgsConstructor;
import model.Reader;

@AllArgsConstructor
public class LoginState {
    public String mensaje;
    public Reader readerLogin;
}

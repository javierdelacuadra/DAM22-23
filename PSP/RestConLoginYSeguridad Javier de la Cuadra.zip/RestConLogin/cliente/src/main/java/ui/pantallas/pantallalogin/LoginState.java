package ui.pantallas.pantallalogin;

import lombok.AllArgsConstructor;
import model.ReaderLogin;

@AllArgsConstructor
public class LoginState {
    public String mensaje;
    public ReaderLogin readerLogin;
}

package com.example.servidorgraphql.common;

public class Constantes {
    private Constantes() {
    }
}

package com.example.servidorgraphql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServidorGraphQlApplicationTests {

    @Test
    void contextLoads() {
    }

}

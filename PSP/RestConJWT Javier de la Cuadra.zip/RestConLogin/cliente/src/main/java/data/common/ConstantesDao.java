package data.common;

public class ConstantesDao {
    public static final String AUTHORIZATION = "Authorization";
    public static final String BEARER_HEADER = "Bearer ";
    public static final String BEARER = "Bearer";

    public ConstantesDao() {
    }

    public static final String APPLICATION_JSON = "application/json";
}

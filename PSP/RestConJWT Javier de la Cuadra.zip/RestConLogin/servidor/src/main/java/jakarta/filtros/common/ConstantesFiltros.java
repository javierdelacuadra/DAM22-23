package jakarta.filtros.common;

public class ConstantesFiltros {

    public static final String USER = "user";
    public static final String MAX_CALLS = "maxCalls";

    public ConstantesFiltros() {
    }
}

package servicios.modelo

data class Camion(
    val id: Int,
    val modelo: String,
    val fechaConstruccion: String,
)
package org.jorgetargz.client.gui.screens.main;

public record MainState(
        String error,
        boolean onLogout) {
}
# Safe Vaults

Java IntelliJ Maven project with a JavaFX Client and a RESTFULL API Server with JAX-RS Jakarta EE 10

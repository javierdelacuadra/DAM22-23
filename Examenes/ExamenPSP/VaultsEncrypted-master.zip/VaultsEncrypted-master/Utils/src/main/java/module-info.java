module Utils {
    requires lombok;
    exports org.jorgetargz.utils.modelo;
    exports org.jorgetargz.utils.common;
    opens org.jorgetargz.utils.modelo;
}
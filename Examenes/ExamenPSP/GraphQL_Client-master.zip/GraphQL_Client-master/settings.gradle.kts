
rootProject.name = "GraphQL_Client"


package me.jorgetargz.ui.screens.common

import me.jorgetargz.ui.screens.main.MainController

open class BaseScreenController {
    var principalController: MainController? = null
    open fun principalCargado() {}
}
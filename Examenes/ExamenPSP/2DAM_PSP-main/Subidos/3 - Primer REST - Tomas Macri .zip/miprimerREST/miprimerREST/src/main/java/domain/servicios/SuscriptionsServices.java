package domain.servicios;

import domain.modelo.Suscription;

public interface SuscriptionsServices {

    Suscription add(Suscription suscription);

    Suscription update(Suscription suscription);

}

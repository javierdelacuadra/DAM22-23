package domain.modelo;

import lombok.Data;

@Data
public class QueryArticlesAndNews {
    private String name_article;
    private String name_newspaper;

}

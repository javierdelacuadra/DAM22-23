package dominio.modelo;

public record PaisDetalle(String nombre, String capital, String region, String moneda, String telefono, String dominio) {
}

package dominio.modelo;

public record Ciudad(int id, String nombre) {
}

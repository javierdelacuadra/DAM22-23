package dao.retrofit.modelo;

import lombok.Data;

@Data
public class ResponseStateItem {
    int id;
    String name;
    String iso2;
}
package config;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

import config.common.ConstantesConfig;
import jakarta.inject.Singleton;
import lombok.Getter;
import lombok.extern.log4j.Log4j2;

import java.io.IOException;

@Getter
@Log4j2
@Singleton
public class Configuracion {


    private String apiKey;

    private String urlApi;

    public Configuracion() {
        ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
        mapper.findAndRegisterModules();

        try {
            JsonNode node = mapper.readTree(
                    Configuracion.class.getClassLoader().getResourceAsStream(ConstantesConfig.CONFIG_FILE));
            this.apiKey = node.get(ConstantesConfig.API_KEY).asText();
            this.urlApi = node.get(ConstantesConfig.URL_API).asText();
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }
    }
}

package dominio.modelo;

public record Estado(int id, String nombre, String iso2) {
}

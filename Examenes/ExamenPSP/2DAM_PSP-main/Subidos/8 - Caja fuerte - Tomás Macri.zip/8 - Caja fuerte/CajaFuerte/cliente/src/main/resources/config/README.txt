Proyecto:

Este proyecto consistirá en un simulador del mundial Qatar 2022.

Se pondrán a disposición del usuario todos los partidos de los grupos del mundial 
para que pueda completar con los resultados que espera que se den.

A medida que el usuario seleccione el partido y añada el resultado se irá actualizando 
la tabla del grupo.

Una vez completados los resultados de los partidos de la fase de grupos, se creará el cuadro final
con los equipos restantes.

El usuario completará con los resultados que crea y se irá actualizando el cuadro final 
hasta que quede el campeón.


Por otro lado, habrá una pestaña de estadísticas donde el usuario podrá ver dos tablas:
Los países más goleadores y los países con mayor cantdad de vallas invictas (partidos 
en donde no le hayan marcado goles).
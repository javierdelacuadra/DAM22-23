package common;

public class CommonConstants {
    public static final String ROOT = "root";

    private CommonConstants() {
    }

}

module seguridad {
    exports org.seguridad.impl;
    requires com.google.common;
    requires lombok;
    requires org.apache.logging.log4j;
}
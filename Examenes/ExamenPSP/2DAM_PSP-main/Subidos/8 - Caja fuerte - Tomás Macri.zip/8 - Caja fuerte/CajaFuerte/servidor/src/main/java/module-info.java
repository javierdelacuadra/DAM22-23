module servidor {
    requires utils;
    requires lombok;
    requires jjwt.api;
    requires jakarta.jakartaee.web.api;
    requires io.vavr;
    requires seguridad;

}
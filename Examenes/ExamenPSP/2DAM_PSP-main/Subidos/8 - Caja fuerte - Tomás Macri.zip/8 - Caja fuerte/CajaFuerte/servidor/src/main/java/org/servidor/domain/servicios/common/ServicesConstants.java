package org.servidor.domain.servicios.common;

public class ServicesConstants {
    public static final String NO_SE_PUDO_AGREGAR_LA_FOLDER = "No se pudo agregar la folder";
    public static final String NO_SE_PUDO_CAMBIAR_LA_CONTRASENA = "No se pudo cambiar la contraseña";
    public static final String NO_SE_PUDO_AGREGAR_EL_MENSAJE = "No se pudo agregar el mensaje";
    public static final String EL_ID_DEBE_SER_UN_NUMERO = "El id debe ser un numero";
    public static final String NO_SE_PUDO_ACTUALIZAR_EL_MENSAJE = "No se pudo actualizar el mensaje";
    public static final String NO_SE_PUDO_AGREGAR_EL_USUARIO = "No se pudo agregar el usuario";

    private ServicesConstants() {
    }

}

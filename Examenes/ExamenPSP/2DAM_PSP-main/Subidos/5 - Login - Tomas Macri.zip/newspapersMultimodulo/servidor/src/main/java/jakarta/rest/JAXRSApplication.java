package jakarta.rest;


import jakarta.common.RestConstants;
import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath(RestConstants.PATH_NEWS)
public class JAXRSApplication extends Application {


}


rootProject.name = "graphqlCliente"


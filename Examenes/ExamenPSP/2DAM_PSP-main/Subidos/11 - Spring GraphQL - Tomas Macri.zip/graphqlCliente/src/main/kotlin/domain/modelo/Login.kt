package domain.modelo

data class Login(val username: String = "", val password: String = "", val role: String ="")
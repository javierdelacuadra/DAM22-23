package dao.retrofit.modelo;

import lombok.Data;

@Data
public class ResponsePaisItem {

    private int id;
    private String name;
    private String iso2;


}
package dao.retrofit.modelo;

import lombok.Data;

@Data
public class ResponseCityItem {

    String name;
    int id;
}
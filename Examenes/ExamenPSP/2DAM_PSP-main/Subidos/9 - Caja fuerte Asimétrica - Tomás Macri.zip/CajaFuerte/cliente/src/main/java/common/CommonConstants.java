package common;

public class CommonConstants {
    public static final String ROOT = "root";
    public static final String SERVER_PK = "serverPK";

    private CommonConstants() {
    }

}

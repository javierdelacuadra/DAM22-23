package org.utils.domain.modelo;

public enum Rol {
    ADMIN, USER
}

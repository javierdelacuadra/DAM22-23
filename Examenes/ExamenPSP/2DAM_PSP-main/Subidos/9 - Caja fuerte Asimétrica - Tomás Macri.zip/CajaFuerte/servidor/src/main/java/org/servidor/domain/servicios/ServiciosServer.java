package org.servidor.domain.servicios;

public interface ServiciosServer {
    String getPublic();
}

package org.servidor.dao;

public interface ServerDao {
    String getPublic();
}

module servidor {
    requires utils;
    requires lombok;
    requires jjwt.api;
    requires jakarta.jakartaee.web.api;
    requires org.apache.logging.log4j;
    requires io.vavr;
    requires seguridad;
}
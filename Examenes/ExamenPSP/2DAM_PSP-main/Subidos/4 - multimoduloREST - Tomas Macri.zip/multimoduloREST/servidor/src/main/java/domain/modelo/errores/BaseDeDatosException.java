package domain.modelo.errores;

public class BaseDeDatosException extends RuntimeException{

    public BaseDeDatosException(String message) {
        super(message);
    }
}

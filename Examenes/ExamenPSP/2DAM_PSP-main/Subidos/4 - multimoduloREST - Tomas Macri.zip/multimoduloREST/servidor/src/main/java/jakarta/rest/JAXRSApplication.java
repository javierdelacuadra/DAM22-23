package jakarta.rest;


import jakarta.rest.common.RestConstants;
import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath(RestConstants.PATH_NEWS)
public class JAXRSApplication extends Application {


}

package dao;

import org.miutils.domain.modelo.TypeArt;

import java.util.List;

public interface TypeDAO {
    List<TypeArt> getAll();

}

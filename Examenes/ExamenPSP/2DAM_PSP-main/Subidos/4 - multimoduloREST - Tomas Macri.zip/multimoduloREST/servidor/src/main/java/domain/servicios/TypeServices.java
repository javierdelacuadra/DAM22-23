package domain.servicios;

import org.miutils.domain.modelo.TypeArt;

import java.util.List;

public interface TypeServices {
    List<TypeArt> getAllTypes();
}

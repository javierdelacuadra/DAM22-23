package ui.screens.common;

import ui.screens.principal.PrincipalController;


public class BaseScreenController {

    private PrincipalController principalController;

    public PrincipalController getPrincipalController() {
        return principalController;
    }

    public void setPrincipalController(PrincipalController principalController) {
        this.principalController = principalController;
    }

    public void principalCargado()
    {
        // principalCargado() is called when the screen is loaded
    }
}

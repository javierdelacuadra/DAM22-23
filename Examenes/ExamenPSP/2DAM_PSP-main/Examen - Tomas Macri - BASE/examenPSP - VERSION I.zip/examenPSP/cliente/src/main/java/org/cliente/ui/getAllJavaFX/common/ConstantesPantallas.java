package org.cliente.ui.getAllJavaFX.common;

public class ConstantesPantallas {


    public static final String PASSWORD = "password";

    private ConstantesPantallas() {
    }

    public static final String FXML_PRINCIPAL_FXML = "/fxml/principal.fxml";
    public static final String APP_TITLE = "Examen D:!";


    public static final String ID = "ID";
    public static final String NOMBRE = "Nombre";
    public static final String NACIMIENTO = "Fecha nacimiento";

    public static final String SALIR_DE_LA_APLICACION = "Salir de la aplicación";
    public static final String CLOSE_WITHOUT_SAVING = "Close without saving?";
}

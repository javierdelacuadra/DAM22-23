package org.cliente.config;

public class ConstantesConfig {


    private ConstantesConfig() {
    }

    public static final String URL_API = "base_url";

    // FUNDAMENTAL EL / DELANTE - SON LAS 3 AM Y PERDI UNA HORA EN ESTO
    public static final String CONFIG_FILE = "/config/config.yaml";
}

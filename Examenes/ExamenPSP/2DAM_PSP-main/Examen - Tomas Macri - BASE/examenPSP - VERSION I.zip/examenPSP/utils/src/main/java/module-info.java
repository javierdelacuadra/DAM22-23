module utils {
    requires lombok;

    exports org.utils.domain.modelo;

    opens org.utils.domain.modelo;
}
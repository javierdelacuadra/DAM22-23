package org.server.jakarta.common;

public class RestConst {
    public static final String PATH_PARAM_ID = "/{id}";
    public static final String ID = "id";
    public static final String NO_SE_ENCONTRO_LA_PERSONA_CON_EL_ID = "No se encontró la persona con el id ";
    public static final String PATH_PERS = "/pers";
    public static final String PATH_SERVER = "/server";
    public static final String NO_SE_PUDO_CREAR_LA_PERSONA = "El objeto enviado no es correcto";
    public static final String MENORES = "/menores";
}

module servidor {
    requires utils;

    requires jakarta.jakartaee.web.api;
}
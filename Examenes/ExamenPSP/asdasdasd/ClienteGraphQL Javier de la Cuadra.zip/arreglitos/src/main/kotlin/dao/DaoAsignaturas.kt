package dao

class DaoAsignaturas {
}
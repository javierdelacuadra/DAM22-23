package servicios.modelo

data class Asignatura(
    val id: Int,
    val nombre: String,
    val nota: Int
)
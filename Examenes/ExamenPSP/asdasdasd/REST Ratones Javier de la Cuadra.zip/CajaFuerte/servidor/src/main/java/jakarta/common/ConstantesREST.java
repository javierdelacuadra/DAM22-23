package jakarta.common;

public class ConstantesREST {

    public ConstantesREST() {
    }

    public static final String ROLE_ADMIN = "admin";
    public static final String ROLE_USER = "user";
    public static final String API_PATH = "/api";
}

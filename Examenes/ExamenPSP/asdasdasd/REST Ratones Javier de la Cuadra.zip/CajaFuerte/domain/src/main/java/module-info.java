module domain {
    requires lombok;
    exports modelo;
    opens modelo;
}
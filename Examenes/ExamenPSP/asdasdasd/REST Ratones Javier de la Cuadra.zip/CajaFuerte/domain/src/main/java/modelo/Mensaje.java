package modelo;

import lombok.Data;

@Data
public class Mensaje {

    private int id;
    private int IDCarpeta;
    private String contenido;
}
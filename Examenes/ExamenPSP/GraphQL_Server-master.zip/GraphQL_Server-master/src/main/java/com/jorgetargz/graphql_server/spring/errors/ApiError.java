package com.jorgetargz.graphql_server.spring.errors;



public record ApiError(String message, String code) {

}

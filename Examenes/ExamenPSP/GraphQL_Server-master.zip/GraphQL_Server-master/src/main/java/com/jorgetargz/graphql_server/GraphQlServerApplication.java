package com.jorgetargz.graphql_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GraphQlServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(GraphQlServerApplication.class, args);
    }

}

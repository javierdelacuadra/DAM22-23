package com.jorgetargz.graphql_server.domain.modelo;

import lombok.Data;

@Data
public class Linea {
    private Integer id;
    private Integer numero;
    private String tipo;
}

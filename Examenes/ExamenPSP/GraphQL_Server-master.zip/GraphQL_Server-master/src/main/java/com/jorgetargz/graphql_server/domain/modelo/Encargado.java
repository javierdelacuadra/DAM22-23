package com.jorgetargz.graphql_server.domain.modelo;

import lombok.Data;

@Data
public class Encargado {
    private Integer id;
    private String nombre;
    private String dni;
}

package com.example.examenxml.network.utils

object NetworkUtils {
    const val BASE_URL = "http://192.168.4.202:8080"
}
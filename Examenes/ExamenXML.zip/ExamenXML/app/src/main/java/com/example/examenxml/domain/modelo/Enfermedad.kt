package com.example.examenxml.domain.modelo

data class Enfermedad(val nombre: String)
